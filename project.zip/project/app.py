from flask import Flask, request, jsonify,render_template,session,redirect,send_file
from pymongo import MongoClient
import json
import random
import os
from datetime import date

client = MongoClient("mongodb://127.0.0.1:27017/")
db= client['food']
users= db['users']
dishes = db['dishes']

app = Flask(__name__)
app.secret_key="secret"

@app.route('/home')
def home():
    with open('./fooditem.json') as f:
        data = f.read()
        data= json.loads(data)
    return render_template('index2.html',dishes=data) 


@app.route('/')
def get():
    return render_template('get.html')

@app.route('/h')
def ho():
    with open('./fooditem.json') as f:
        data = f.read()
        data= json.loads(data)
    return render_template('index.html',dishes=data) 

@app.route('/cart')
def cart():
    res= users.find_one({'username':session['name']})
    cart = res['cart']
    total =0
    for i in cart:
        print(i)
        for j in range(int(i['count'])):
            total+=i['price']
    return render_template('cart.html',data=cart,total=total)

@app.route('/checkout')
def checkout():
    total = request.args.get('total')
    return render_template('payment.html',total=total)


@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/image')
def serve_image():
    path =request.args.get('file')
    path =os.path.join('static', path)
    return send_file(path, mimetype='image/jpeg')

@app.route('/log')
def log():
    return render_template('login.html')

@app.route('/reg')
def reg():
    return render_template('registration.html')

@app.route('/account')
def account():
    data = users.find_one({"username":session['name']})  
    total=0
    x=dict(data)
    for j in x['orders']:
        for k in j['order']:
            total+=k['price']
    return render_template('acoount.html',data=x,total=total)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/offers')
def offers():
    return render_template('offers.html')

@app.route('/services')
def services():
    return render_template('Services.html')

@app.route('/register',methods=['post','get'])
def register():
    username=request.form['name']
    email=request.form['phone']
    password=request.form['pass']
    confirmpass=request.form['repass']
    k={}
    k['username']=username
    k['mail']=email
    k['password']=password 
    k['orders']=[]
    k['cart']=[]
    res=users.find_one({"username":username})
    if res:
        return render_template('registration.html',status="Username already exists")
    else:
        if password != confirmpass:
            return render_template('registration.html',status='Passwords do not match')
        elif len(password)<8:
            return render_template('registration.html',status="Password must be greater than 7 characters")
        else:
            users.insert_one(k)
            return render_template('registration.html',stat="Registration successful")

@app.route('/login',methods=['post','get'])
def login():
    user=request.form['username']
    password=request.form['password']
    res=users.find_one({"username":user})   
    if res and dict(res)['password']==password:
        session['name']=user
        return redirect('/home')
    else:
        return render_template('login.html',status='User does not exist or wrong password')

@app.route('/setP',methods=['post','get'])
def setP():
    user=request.form['username']
    password=request.form['password1']
    password2=request.form['password2']
    if (password!=password2):
        return render_template('forgot.html',status='Passwords doesnt match')
    res=users.update_one({"username":user},{"$set":{"password":password}})   
    return render_template('login.html',status='password resetted')

@app.route('/for')
def forp():
    return render_template('forgot.html')

@app.route('/addToCart')
def addtocart():
    id= request.args.get('id')
    with open('./fooditem.json') as f:
        data = f.read()
        data= json.loads(data)
    res={}
    for i in data:
        if (i['id']==int(id)):
            res=i
    f=0
    data = users.find_one({'username':session['name']})
    for i in data['cart']:
        if res['id'] == i['id']:
            result = users.update_one(
            {'username':session['name'], "cart.id": i['id']},
            {"$inc": {"cart.$.count": 1}})
            f=1
    if f==0:
        res['count']=1
        users.update_one({'username':session['name']},{'$push':{'cart':res}})
    return redirect('/cart')

@app.route('/delItem')
def deel():
    id= request.args.get('id')
    with open('./fooditem.json') as f:
        data = f.read()
        data= json.loads(data)
    res={}
    for i in data:
        if (i['id']==int(id)):
            res=i
    data = users.find_one({'username':session['name']})
    for i in data['cart']:
        if int(id) == i['id'] :
            if(i['count']==1):
                users.update_one({'username':session['name']},{'$pull':{'cart':res}})
            else:
                print(i)
                result = users.update_one(
                {'username':session['name'], "cart.id": i['id']},
                {"$inc": {"cart.$.count": -1}})
    return redirect('/cart')


@app.route('/placeOrder')
def place():
    total = request.args.get('total')
    data = users.find_one({'username':session['name']})

    users.update_one({'username':session['name']},{'$push':{'orders':{
        'order':data['cart'],
        'date':str(date.today())
    }}})
    users.update_one({'username':session['name']},{'$set':{'cart':[]}})
    return render_template('/order.html')




if __name__ == '__main__':
    app.run(debug=True)
